
<?php $__env->startSection('title', 'Product | Aranya'); ?>

<?php $__env->startSection('content'); ?>
<div id="tableHover" class="col-lg-12 col-12 layout-spacing" style="padding: 15px 0;">
    <div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12 d-flex justify-content-between">
                    <h4>Product</h4>
                </div>                 
            </div>
        </div>
    </div>
   <create-product :prp_artist="<?php echo e($artist); ?>" :prp_vendor="<?php echo e($vendor); ?>" :prp_brand="<?php echo e($brand); ?>" :prp_care="<?php echo e($care); ?>"
     :prp_consignment="<?php echo e($consignment); ?>" :prp_designer="<?php echo e($designer); ?>" :prp_embellish="<?php echo e($embellish); ?>"
     :prp_fabric="<?php echo e($fabric); ?>" :prp_fit="<?php echo e($fit); ?>" :prp_ingredient="<?php echo e($ingredient); ?>" :prp_making="<?php echo e($making); ?>"
     :prp_season="<?php echo e($season); ?>" :prp_colour="<?php echo e($colour); ?>" :prp_size="<?php echo e($size); ?>" :prp_variety="<?php echo e($variety); ?>" :prp_tax="<?php echo e($tax); ?>"
    />
</div>    

<!-- end modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/product.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server-74\htdocs\newaranya\resources\views/pages/product/create_product.blade.php ENDPATH**/ ?>