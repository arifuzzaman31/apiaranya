
<?php $__env->startSection('title', 'Order Details | Aranya'); ?>
<?php $__env->startSection('content'); ?>
<div id="tableHover" class="col-lg-12 col-12 layout-spacing" style="padding: 15px 0;">
<div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12 d-flex justify-content-between">
                    <h4>Order-<?php echo e($orders->order_id); ?></h4>
                </div>                 
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div>
                <p class="mb-2"><b>Tracking ID: </b><?php echo e($orders->tracking_id); ?></p>
                <table class="table table-bordered table-hover mb-4">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Product Name</th>
                            <th>Picture</th>
                            <th>Colour</th>
                            <th>Size</th>
                            <th>Fabric</th>
                            <th>Unit Price</th>
                            <th>Qty</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($detail->product->product_name); ?></td>
                                <td>
                                    <img height="60" src="<?php echo e($detail->product->product_image); ?>" />
                                </td>
                                <td><?php echo e($detail->colour->color_name); ?></td>
                                <td><?php echo e($detail->size->size_name); ?></td>
                                <td><?php echo e($detail->fabric->fabric_name); ?></td>
                                <td><?php echo e($detail->selling_price); ?></td>
                                <td><?php echo e($detail->quantity); ?></td>
                                <td><?php echo e($detail->total_selling_price); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr  class="text-center">
                                <td colspan="9"><p>No Data found</p></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td colspan="8" class="text-right">Total: </td>
                            <td><?php echo e($orders->total_price); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>  
        </div>
        <div class="row widget-content widget-content-area">
            <div class="col-md-6 col-4">
                <h6 class="text-center">Delivery Progress</h6>
                <table class="table table-bordered table-hover mb-4">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Status</th>
                            <th>Date</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders->delivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deliv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($deliv->shipping_date); ?></td>
                                <td><?php echo e($deliv->position_status); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr  class="text-center">
                                <td colspan="3"><p>No Data found</p></td>
                            </tr>
                            <?php endif; ?>
                    </tbody>
                </table>
            </div>  
        </div>
    </div>
</div>    
<!-- end modal -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server-74\htdocs\newaranya\resources\views/pages/customer/order_details.blade.php ENDPATH**/ ?>