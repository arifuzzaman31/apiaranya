
<?php $__env->startSection('title', 'Artist | Aranya'); ?>

<?php $__env->startSection('content'); ?>
<div id="tableHover" class="col-lg-12 col-12 layout-spacing" style="padding: 15px 0;">
    <div class="statbox">
        <div class="widget-header">
            <view-artist />
        </div>
    </div>
</div>    
<!-- end modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('js/attribute.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server-74\htdocs\newaranya\resources\views/pages/attribute/artist/artist.blade.php ENDPATH**/ ?>