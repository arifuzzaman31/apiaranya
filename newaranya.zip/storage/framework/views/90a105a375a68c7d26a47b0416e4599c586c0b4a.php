
<?php $__env->startSection('title', 'Customer Order | Aranya'); ?>

<?php $__env->startSection('content'); ?>
<div id="tableHover" class="col-lg-12 col-12 layout-spacing" style="padding: 15px 0;">
<div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12 d-flex justify-content-between">
                    <h4>Order of <?php echo e($customer->name); ?></h4>
                </div>                 
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <table class="table table-bordered table-hover mb-4">
                <thead>
                    <tr>
                        <th>SL</th>
                        <th>OrderID</th>
                        <th>Price</th>
                        <th>Shipping</th>
                        <th>PaymentBy</th>
                        <th class="text-center">Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($order->id); ?></td>
                            <td><?php echo e($order->order_id); ?></td>
                            <td><?php echo e($order->total_price); ?></td>
                            <td><?php echo e($order->shipping_method); ?></td>
                            <td><?php echo e($order->payment_method); ?></td>
                            <td class="text-center">
                                <?php if($order->status != 0): ?>
                                <span>
                                    <?php if($order->order_position == 0): ?><span class="badge badge-info">Pending</span><?php endif; ?>
                                    <?php if($order->order_position == 1): ?><span class="badge badge-primary">Process</span><?php endif; ?>
                                    <?php if($order->order_position == 2): ?><span class="badge badge-warning">On Delivery</span><?php endif; ?>
                                    <?php if($order->order_position == 3): ?><span class="badge badge-success">Delivered</span><?php endif; ?>
                                </span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Cancel</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('admin/user-order-detail',$order->id)); ?>" type="button">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="text-center">
                            <td colspan="7"><p>No Order found</p></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo $orders->links(); ?>

        </div>
    </div>
</div>    
<!-- end modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
        .pagination{
            float: right;
            margin-top: 10px;
        }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server-74\htdocs\newaranya\resources\views/pages/customer/order.blade.php ENDPATH**/ ?>