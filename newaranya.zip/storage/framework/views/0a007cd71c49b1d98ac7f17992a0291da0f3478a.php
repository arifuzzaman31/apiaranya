
<?php $__env->startPush('style'); ?>
<link href="<?php echo e(asset('admin-assets/plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin-assets/assets/css/dashboard/dash_2.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row layout-top-spacing">
    <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12 layout-spacing">
        <div class="widget widget-account-invoice-two">
            <div class="widget-content">
                <div class="account-box">
                    <div class="info">
                        <h5 class=""><?php echo e($inf['title']); ?></h5>
                        <p class="inv-balance"><?php echo e($inf['qty']); ?></p>
                    </div>
                    
                </div>
            </div>
        </div>
    </div> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('admin-assets/plugins/apex/apexcharts.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server-74\htdocs\newaranya\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>