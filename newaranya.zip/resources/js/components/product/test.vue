!<template>
    <div class="arif"> 
        <h1>hello arif vai?</h1>
    </div>
 
</template>

<script>
export default {

}
</script>

<style>

</style>