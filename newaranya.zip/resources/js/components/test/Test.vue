<script>
export default {
    setup: () => ({
        title: 'How To Install Vue 3 in Laravel 8 From Scratch'
    })
}
</script>
<template>
    <div>
        <h1>{{title}}</h1>
    </div>
</template>
