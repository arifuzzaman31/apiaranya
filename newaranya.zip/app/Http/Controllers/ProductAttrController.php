<?php

namespace App\Http\Controllers;

use App\Models\Product_Attr;
use Illuminate\Http\Request;

class ProductAttrController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product_Attr  $product_Attr
     * @return \Illuminate\Http\Response
     */
    public function show(Product_Attr $product_Attr)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product_Attr  $product_Attr
     * @return \Illuminate\Http\Response
     */
    public function edit(Product_Attr $product_Attr)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product_Attr  $product_Attr
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product_Attr $product_Attr)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product_Attr  $product_Attr
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product_Attr $product_Attr)
    {
        //
    }
}
